const DISTRICTS = ['Ate','Barranco','Breña','Carabayllo','Chorrillos','Comas','El Agustino','Independencia','Jesús María','La Molina','La Victoria','Lince','Los Olivos','Magdalena del Mar','Miraflores','Pueblo Libre','Puente Piedra','Rímac','San Borja','San Isidro','San Juan de Lurigancho','San Juan de Miraflores','San Luis','San Martín de Porres','San Miguel','Santa Anita','Santiago de Surco','Surquillo','Villa El Salvador','Villa María del Triunfo'];
const TYPES = [{id:'Perro',emoji:'🐶'},{id:'Gato',emoji:'🐱'},{id:'Loro',emoji:'🦜'},{id:'Otro',emoji:'🐾'}];
const $ = id => document.getElementById(id);
const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
let currentUser = read('mp_session', null);
let activeTab = 'home';
let searchTerm = '';
let selectedType = 'Todos';
let selectedDistrict = 'Todos';
let photoData = '';
let alertTypes = ['Perro','Gato','Loro','Otro'];
let alertDistrict = '';
let alertSaved = false;

function populateDistricts(){
  const opts = '<option value="">Selecciona tu distrito</option>' + DISTRICTS.map(d=>`<option>${d}</option>`).join('');
  $('regDistrict').innerHTML = opts;
}
function switchAuth(register){
  $('loginForm').classList.toggle('hidden',register); $('registerForm').classList.toggle('hidden',!register);
  $('authTitle').textContent = register ? 'Crea tu cuenta' : 'Inicia sesión';
  $('authSubtitle').textContent = register ? 'Regístrate para publicar avisos y configurar alertas.' : 'Ingresa para publicar avisos y recibir alertas de tu zona.';
  $('switchText').textContent = register ? '¿Ya tienes cuenta?' : '¿Aún no tienes cuenta?';
  $('switchAuth').textContent = register ? 'Iniciar sesión' : 'Crear cuenta';
}
$('switchAuth').addEventListener('click',()=>switchAuth($('registerForm').classList.contains('hidden')));
$('registerForm').addEventListener('submit',e=>{
  e.preventDefault();
  const users=read('mp_users',[]), email=$('regEmail').value.trim().toLowerCase();
  if(users.some(u=>u.email===email)){toast('Ya existe una cuenta con ese correo.');return;}
  const user={id:Date.now().toString(),name:$('regName').value.trim(),email,phone:$('regPhone').value.trim(),district:$('regDistrict').value,password:$('regPassword').value};
  users.push(user);write('mp_users',users);currentUser={id:user.id,name:user.name,email:user.email,phone:user.phone,district:user.district};write('mp_session',currentUser);enterApp();toast('¡Cuenta creada! Bienvenida/o.');
});
$('loginForm').addEventListener('submit',e=>{
  e.preventDefault(); const email=$('loginEmail').value.trim().toLowerCase(), pass=$('loginPassword').value;
  const user=read('mp_users',[]).find(u=>u.email===email && u.password===pass);
  if(!user){toast('Correo o contraseña incorrectos.');return;}
  currentUser={id:user.id,name:user.name,email:user.email,phone:user.phone,district:user.district};write('mp_session',currentUser);enterApp();
});
function enterApp(){ $('authView').classList.add('hidden');$('appView').classList.remove('hidden');$('topAvatar').textContent=(currentUser?.name||'U').slice(0,1).toUpperCase();render(); }
function logout(){currentUser=null;localStorage.removeItem('mp_session');$('appView').classList.add('hidden');$('authView').classList.remove('hidden');$('loginForm').reset();switchAuth(false);}
$('topAvatar').addEventListener('click',()=>go('profile'));
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>go(b.dataset.tab)));
function go(tab){activeTab=tab;document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));render();window.scrollTo(0,0);}
function pets(){return read('mp_pets',[])}
function typeEmoji(type){return TYPES.find(t=>t.id===type)?.emoji||'🐾'}
function safe(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function render(){const root=$('pageContent');if(activeTab==='home')root.innerHTML=homeHTML();if(activeTab==='report')root.innerHTML=reportHTML();if(activeTab==='alerts')root.innerHTML=alertsHTML();if(activeTab==='profile')root.innerHTML=profileHTML();bindPage();}
function homeHTML(){
 const list=pets().filter(p=>(selectedType==='Todos'||p.type===selectedType)&&(selectedDistrict==='Todos'||p.district===selectedDistrict)&&(!searchTerm||[p.name,p.description,p.district,p.type].join(' ').toLowerCase().includes(searchTerm.toLowerCase()))).sort((a,b)=>b.created-a.created);
 return `<section class="welcome"><h1>Ayudemos a volver a casa ❤️</h1><p>Encuentra avisos cerca de ti o publica una alerta para que tu comunidad pueda ayudar.</p><div class="big-pets">🐶🐱</div></section>
 <div class="searchbox"><input id="homeSearch" type="search" placeholder="Buscar por nombre, distrito o descripción..." value="${safe(searchTerm)}"></div>
 <div class="section-head"><h2>Busca por tipo</h2><small>Filtra los avisos</small></div><div class="chips">${['Todos','Perro','Gato','Loro','Otro'].map(t=>`<button class="chip ${selectedType===t?'active':''}" data-type="${t}">${t==='Todos'?'🐾':typeEmoji(t)} ${t}</button>`).join('')}</div>
 <div class="section-head"><h2>Distritos</h2><small>Lima Metropolitana</small></div><div class="chips">${['Todos',currentUser?.district,'Santa Anita','Ate','La Molina','Comas','San Borja','Miraflores'].filter((v,i,a)=>v&&a.indexOf(v)===i).map(d=>`<button class="chip ${selectedDistrict===d?'active':''}" data-district="${d}">${d}</button>`).join('')}</div>
 <div class="section-head"><h2>Últimos avisos</h2><small>${list.length} publicación(es)</small></div>
 ${list.length?`<div class="pet-grid">${list.map(petCard).join('')}</div>`:`<div class="empty"><strong>🐾</strong><b>Aún no hay avisos en este filtro.</b><br>Publica una mascota perdida o encontrada para comenzar a ayudar.</div>`}
 <div class="cta-row"><button class="btn primary" data-go="report">📣 Reportar mascota perdida</button><button class="btn green" data-go="report" data-found="1">🐾 Reportar mascota encontrada</button></div>
 <div class="notice">ℹ️ Esta versión guarda los avisos en este dispositivo. Para que otros vecinos los vean y reciban notificaciones reales, habrá que conectar una base de datos y un servicio de alertas en línea.</div>`;
}
function petCard(p){return `<article class="pet-card"><div class="pet-photo">${p.photo?`<img src="${p.photo}" alt="Foto de ${safe(p.name)}">`:typeEmoji(p.type)}</div><div class="pet-info"><span class="status ${p.status==='Encontrado'?'found':''}">${p.status==='Perdido'?'● PERDIDO':'● ENCONTRADO'}</span><h3>${safe(p.name||p.type)}</h3><p>📍 ${safe(p.district)} · ${safe(p.type)}</p><p>🗓️ ${safe(p.date||'Fecha no indicada')}</p><p>${safe((p.description||'').slice(0,90))}</p><div class="pet-actions"><button class="small-btn" data-detail="${p.id}">Ver aviso</button>${p.phone?`<button class="small-btn" data-contact="${safe(p.phone)}" data-name="${safe(p.name||'mascota')}">Contactar</button>`:''}</div></div></article>`;}
function reportHTML(){return `<section class="form-card"><h2>Publicar un aviso</h2><p>Completa los datos para ayudar a identificar y encontrar a la mascota.</p><form id="petForm">
 <div class="field"><span>¿Qué deseas reportar?</span><div class="radio-row"><label class="radio-pill"><input type="radio" name="status" value="Perdido" checked> Perdida</label><label class="radio-pill"><input type="radio" name="status" value="Encontrado"> Encontrada</label></div></div>
 <div class="field"><span>Tipo de animal</span><select id="petType" required>${TYPES.map(t=>`<option value="${t.id}">${t.emoji} ${t.id}</option>`).join('')}</select></div>
 <div class="field"><span>Nombre de la mascota (si lo conoces)</span><input id="petName" placeholder="Ej. Max" maxlength="45"></div>
 <div class="field"><span>Fotografía</span><div class="photo-picker">📷 Selecciona una foto clara de la mascota<input id="petPhoto" type="file" accept="image/*"><img id="photoPreview" class="photo-preview hidden" alt="Vista previa"></div></div>
 <div class="field"><span>Distrito donde se perdió o encontró</span><select id="petDistrict" required><option value="">Selecciona un distrito</option>${DISTRICTS.map(d=>`<option ${d===currentUser?.district?'selected':''}>${d}</option>`).join('')}</select></div>
 <div class="field"><span>Fecha del suceso</span><input id="petDate" type="date" required value="${new Date().toISOString().slice(0,10)}"></div>
 <div class="field"><span>Descripción y señas particulares</span><textarea id="petDescription" placeholder="Color, tamaño, collar, zona exacta, comportamiento..." required maxlength="600"></textarea></div>
 <div class="field"><span>Teléfono de contacto</span><input id="petPhone" type="tel" value="${safe(currentUser?.phone||'')}" placeholder="999 999 999" required maxlength="20"></div>
 <div class="field"><span>Referencia de ubicación (opcional)</span><input id="petLocation" placeholder="Ej. Parque cercano, avenida o urbanización"></div>
 <div class="notice">Por seguridad, publica una referencia de ubicación y evita compartir datos personales sensibles. Verifica la identidad de quien contacte antes de entregar una mascota.</div>
 <button class="btn primary" type="submit">Publicar aviso</button></form></section>`;}
function alertsHTML(){const saved=read('mp_alert_pref',null);const matches=pets().filter(p=>p.status==='Perdido'&&(!saved||!saved.district||p.district===saved.district)&&(!saved||saved.types.includes(p.type)));return `<section class="form-card"><h2>🔔 Mis alertas</h2><p>Elige dónde y sobre qué animales quieres recibir avisos. En esta versión las coincidencias se muestran dentro de la app.</p><form id="alertForm"><div class="field"><span>Distrito de interés</span><select id="alertDistrict"><option value="">Todos los distritos</option>${DISTRICTS.map(d=>`<option ${saved?.district===d?'selected':''}>${d}</option>`).join('')}</select></div><div class="field"><span>Tipos de mascota</span>${TYPES.map(t=>`<label class="toggle-row"><input type="checkbox" name="alertType" value="${t.id}" ${(saved?.types||TYPES.map(x=>x.id)).includes(t.id)?'checked':''}> ${t.emoji} ${t.id}</label>`).join('')}</div><button class="btn primary" type="submit">Guardar mis preferencias</button></form></section><div class="section-head"><h2>Avisos que coinciden</h2><small>${matches.length} coincidencia(s)</small></div>${matches.length?`<div class="pet-grid">${matches.map(petCard).join('')}</div>`:`<div class="empty"><strong>🔔</strong><b>No hay coincidencias por ahora.</b><br>Cuando existan avisos que coincidan con tus filtros, aparecerán aquí.</div>`}<div class="notice">Las notificaciones push al celular y las alertas compartidas entre usuarios se activarán al conectar el servicio en línea.</div>`;}
function profileHTML(){const mine=pets().filter(p=>p.userId===currentUser?.id);return `<section class="profile-card"><div class="profile-head"><div class="profile-avatar">🐾</div><div><h3>${safe(currentUser?.name||'Usuario')}</h3><p>${safe(currentUser?.email||'')}</p></div></div><div class="divider"></div><p>📱 ${safe(currentUser?.phone||'Sin teléfono')}</p><p>📍 ${safe(currentUser?.district||'Sin distrito')}</p><p>🗂️ ${mine.length} aviso(s) publicado(s) desde este dispositivo</p></section><div class="section-head"><h2>Mis publicaciones</h2></div>${mine.length?`<div class="pet-grid">${mine.map(petCard).join('')}</div>`:`<div class="empty"><strong>📄</strong>Aún no has publicado avisos.</div>`}<button id="logoutBtn" class="btn secondary" style="width:100%;margin-top:14px">Cerrar sesión</button><div class="notice">Prototipo de demostración. Los datos están guardados localmente y no constituyen todavía una cuenta segura ni un servicio comunitario en línea.</div>`;}
function bindPage(){
 $('homeSearch')?.addEventListener('input',e=>{searchTerm=e.target.value;const pos=e.target.selectionStart;const root=$('pageContent');root.innerHTML=homeHTML();const input=$('homeSearch');input.focus();input.setSelectionRange(pos,pos);bindPage();});
 document.querySelectorAll('[data-type]').forEach(b=>b.addEventListener('click',()=>{selectedType=b.dataset.type;render();}));
 document.querySelectorAll('[data-district]').forEach(b=>b.addEventListener('click',()=>{selectedDistrict=b.dataset.district;render();}));
 document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>{go(b.dataset.go);if(b.dataset.found){const found=document.querySelector('input[name="status"][value="Encontrado"]');if(found)found.checked=true;}}));
 document.querySelectorAll('[data-contact]').forEach(b=>b.addEventListener('click',()=>{const phone=b.dataset.contact.replace(/\D/g,'');if(!phone){toast('Este aviso no tiene teléfono.');return;}const msg=encodeURIComponent(`Hola, te contacto por el aviso de ${b.dataset.name} en Mascotas Perdidas.`);window.location.href=`https://wa.me/51${phone}?text=${msg}`;}));
 document.querySelectorAll('[data-detail]').forEach(b=>b.addEventListener('click',()=>{const p=pets().find(x=>x.id===b.dataset.detail);if(p)showPetDetail(p);}));
 $('petPhoto')?.addEventListener('change',handlePhoto);
 $('petForm')?.addEventListener('submit',savePet);
 $('alertForm')?.addEventListener('submit',saveAlerts);
 $('logoutBtn')?.addEventListener('click',logout);
}
function handlePhoto(e){const file=e.target.files?.[0];if(!file)return;if(!file.type.startsWith('image/')){toast('Selecciona una imagen.');return;}if(file.size>12*1024*1024){toast('La foto supera 12 MB. Elige una más pequeña.');return;}const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const canvas=document.createElement('canvas'),max=1000,scale=Math.min(1,max/Math.max(img.width,img.height));canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);photoData=canvas.toDataURL('image/jpeg',.72);$('photoPreview').src=photoData;$('photoPreview').classList.remove('hidden');};img.src=reader.result;};reader.readAsDataURL(file);}
function savePet(e){e.preventDefault();const p={id:Date.now().toString(),userId:currentUser.id,status:new FormData(e.target).get('status'),type:$('petType').value,name:$('petName').value.trim(),photo:photoData,district:$('petDistrict').value,date:$('petDate').value,description:$('petDescription').value.trim(),phone:$('petPhone').value.trim(),location:$('petLocation').value.trim(),created:Date.now()};const list=pets();list.unshift(p);try{write('mp_pets',list);}catch(err){toast('No hay espacio suficiente para guardar la foto. Prueba con otra imagen.');return;}photoData='';go('home');toast('Aviso guardado en este dispositivo.');}
function saveAlerts(e){e.preventDefault();const types=[...document.querySelectorAll('input[name="alertType"]:checked')].map(x=>x.value);if(!types.length){toast('Selecciona al menos un tipo de mascota.');return;}write('mp_alert_pref',{district:$('alertDistrict').value,types});toast('Preferencias de alertas guardadas.');render();}
function showPetDetail(p){const message=`${p.status.toUpperCase()} · ${p.type}\nNombre: ${p.name||'No indicado'}\nDistrito: ${p.district}\nFecha: ${p.date}\nDescripción: ${p.description}\nReferencia: ${p.location||'No indicada'}\nContacto: ${p.phone}`;alert(message);}
let toastTimer;function toast(message){const t=$('toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2600);}
populateDistricts();if(currentUser&&read('mp_users',[]).some(u=>u.id===currentUser.id))enterApp();else{currentUser=null;localStorage.removeItem('mp_session');switchAuth(false);}
