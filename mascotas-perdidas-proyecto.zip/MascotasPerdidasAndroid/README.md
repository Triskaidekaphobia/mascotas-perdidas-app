# Mascotas Perdidas — prototipo Android

Aplicación Android inicial con interfaz móvil en español. Incluye registro e inicio de sesión local, creación de avisos con foto, tipos de animal (perro, gato, loro y otro), filtros por distrito, avisos perdidos/encontrados, preferencias de alertas y perfil.

## Importante: alcance de esta versión

Esta entrega es un **prototipo local para instalar y probar**. La información se guarda en el almacenamiento de cada teléfono mediante `localStorage` de WebView. Por eso:

- Las cuentas no son cuentas reales en un servidor.
- Las publicaciones no se comparten con otros teléfonos.
- Las alertas solo muestran coincidencias dentro de la misma instalación; todavía no hay notificaciones push.
- La contraseña se guarda localmente en esta demostración. No uses contraseñas importantes ni información sensible.
- Antes de publicarla para uso real, hay que integrar autenticación segura, base de datos, almacenamiento de fotos, notificaciones y moderación.

## Cómo generar un APK en Windows con Android Studio

1. Instala Android Studio desde https://developer.android.com/studio.
2. Descomprime este ZIP.
3. Abre Android Studio y elige **Open**. Selecciona la carpeta `MascotasPerdidasAndroid` (la que contiene `settings.gradle`).
4. Acepta la instalación de Android SDK Platform 35 y espera a que termine Gradle Sync.
5. Conecta tu teléfono Android con depuración USB o inicia un emulador y pulsa **Run** para probar.
6. Para crear el APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Android Studio mostrará el APK generado. Normalmente estará en `app/build/outputs/apk/debug/app-debug.apk`.

## Alternativa: compilar en la nube con GitHub Actions

Este proyecto incluye `.github/workflows/build-apk.yml`.

1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de esta carpeta al repositorio (no solo el ZIP como un archivo).
3. Abre la pestaña **Actions** y ejecuta **Construir APK Android** con **Run workflow**. También se ejecuta al subir cambios a `main` o `master`.
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto **MascotasPerdidas-APK**. Dentro estará `app-debug.apk`.
5. Pasa el APK a tu teléfono e instálalo. Android puede pedirte autorizar la instalación desde esa fuente.

El flujo de GitHub requiere una cuenta de GitHub y que Actions esté habilitado para el repositorio.

## Estructura

- `app/src/main/assets/www/`: interfaz y lógica de la app.
- `app/src/main/java/com/mascotasperdidas/app/MainActivity.java`: contenedor Android WebView y selector de fotos.
- `app/src/main/AndroidManifest.xml`: configuración Android.
- `.github/workflows/build-apk.yml`: compilación automática del APK en GitHub Actions.

## Siguiente etapa recomendada

Conectar un backend real para que un aviso publicado en Santa Anita aparezca en los celulares de otros usuarios de Santa Anita y active alertas por distrito, tipo de animal y cercanía.
